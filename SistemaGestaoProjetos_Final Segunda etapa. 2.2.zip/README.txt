# 📌 README – Sistema de Gestão de Projetos

## 📖 Descrição
Este sistema em **Java (console)** permite a **gestão de usuários, projetos, equipes e tarefas**.
Foi desenvolvido para fins acadêmicos/didáticos.

---

## Arquivos
- SistemaFinal.java (arquivo principal - copiar para NetBeans)
- README.txt (este arquivo)

---

## Como executar no NetBeans

1. Abra o NetBeans e crie um novo projeto Java (Java with Ant or Java with Maven).
2. Dentro do projeto, apague qualquer arquivo Main.java criado automaticamente.
3. Crie um novo arquivo Java chamado `SistemaFinal.java` dentro da pasta `Source Packages` (ou copie o conteúdo para o pacote padrão).
4. Cole o conteúdo do `SistemaFinal.java` fornecido no arquivo.
5. Execute o projeto (Run Project / F6).

---

## Como executar no terminal

1. Salve o arquivo `SistemaFinal.java`.
2. Compile:
   ```
   javac SistemaFinal.java
   ```
3. Execute:
   ```
   java SistemaFinal
   ```

---

## Usuários pré-cadastrados
- Lucas Silva — login: lucas.silva — senha: Padrao123
- Carol Cavalcante — login: carol.cavalcante — senha: Padrao123
- Thamiris Marie — login: thamiris.marie — senha: Padrao123
- Rodrigo Bat — login: rodrigo.bat — senha: Padrao123

---

## Exportação
Ao exportar, gera-se o arquivo `projetos_export.csv` na pasta do projeto.
